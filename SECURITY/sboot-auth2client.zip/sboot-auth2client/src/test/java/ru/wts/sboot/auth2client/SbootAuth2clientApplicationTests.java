package ru.wts.sboot.auth2client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootAuth2clientApplicationTests {

	@Test
	void contextLoads() {
	}

}
