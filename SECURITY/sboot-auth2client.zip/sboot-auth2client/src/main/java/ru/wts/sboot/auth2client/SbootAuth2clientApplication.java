package ru.wts.sboot.auth2client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootAuth2clientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootAuth2clientApplication.class, args);
	}

}
